#!/bin/sh
# 小白无序修改工具 - Overlay 安装脚本
# 用法: 将此包上传到路由器，然后运行:
#   sh install.sh
#
# 注意: 需要 root 权限运行
# 安装后需要刷新 LuCI 页面或重启 LuCI: /etc/init.d/rpcd restart

OVERLAY_DIR="/overlay/upper"

install_file() {
	local src="$1"
	local dst="${OVERLAY_DIR}/$1"
	local dstdir

	dstdir="$(dirname "$dst")"
	mkdir -p "$dstdir"

	cp -f "$src" "$dst"
	echo "  [OK] $1"
}

echo "=========================================="
echo "  小白无序修改工具 mocktool 安装脚本"
echo "=========================================="
echo ""

# 检查 root
if [ "$(id -u)" -ne 0 ]; then
	echo "错误: 需要 root 权限运行!"
	exit 1
fi

# 检查 overlay 目录
if [ ! -d "$OVERLAY_DIR" ]; then
	echo "警告: $OVERLAY_DIR 不存在，尝试使用 /overlay"
	OVERLAY_DIR="/overlay"
	if [ ! -d "$OVERLAY_DIR" ]; then
		echo "错误: 找不到 overlay 目录！"
		exit 1
	fi
fi

echo "安装到: $OVERLAY_DIR"
echo ""

# 安装文件
install_file "etc/config/mocktool"
install_file "usr/bin/mocktool"
install_file "usr/libexec/mocktool-luci"
install_file "usr/lib/lua/luci/controller/mocktool.lua"
install_file "usr/lib/lua/luci/view/mocktool.htm"
install_file "usr/share/rpcd/acl.d/mocktool.json"
install_file "www/luci-static/resources/mocktool.css"
install_file "www/luci-static/resources/mocktool-logo-white.png"
install_file "www/luci-static/resources/mocktool-logo-dark.png"

echo ""
echo "安装完成！"
echo ""
echo "请执行以下操作使配置生效:"
echo "  1. 重启 rpcd:    /etc/init.d/rpcd restart"
echo "  2. 重启 LuCI:    /etc/init.d/uhttpd restart"
echo "  3. 清除 LuCI 缓存: rm -rf /tmp/luci-*"
echo "  4. 刷新浏览器页面"
echo ""
echo "然后进入 网络 -> 小白无序修改工具 使用"
echo "=========================================="
