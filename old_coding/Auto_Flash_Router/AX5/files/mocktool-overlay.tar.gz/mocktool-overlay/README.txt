小白无序修改工具 (mocktool) v0.0.1-r1
============================================
作者: Ushiromiya (sunbk201)
网站: Wuxuluyou.Top
许可: MIT

覆盖 Overlay 安装包
-------------------
直接解压到路由器 overlay 分区即可使用。

使用方法 (两种):

方法1 - SSH 安装 (推荐):
  1. 将整个 mocktool-overlay 目录上传到路由器 /tmp
  2. SSH 登录路由器执行:
       sh /tmp/mocktool-overlay/install.sh

方法2 - 手动覆盖:
  1. 将文件按目录结构复制到 /overlay/upper/
     (目录结构即为路由器根目录结构)
  2. 执行:
       /etc/init.d/rpcd restart
       /etc/init.d/uhttpd restart
       rm -rf /tmp/luci-*
  3. 刷新浏览器

方法3 - tar 包直接解压:
  1. 将 tar 包上传到路由器
  2. SSH 执行:
       tar -xzf mocktool-overlay.tar.gz -C /overlay/upper/
       ... (重启服务同上)

使用说明
--------
安装后在 LuCI 管理界面:
  网络 -> 小白无序修改工具

功能:
  - 查看系统信息 (Hostname, WAN/LAN MAC, LAN IP)
  - 一键随机修改 MAC & IP
  - 自定义修改 WAN MAC / LAN MAC / LAN IP
  - 定时自动修改 (crontab)

文件清单
--------
  etc/config/mocktool                   - UCI 配置文件
  usr/bin/mocktool                      - 核心二进制程序
  usr/libexec/mocktool-luci             - LuCI 后端 Shell 脚本
  usr/share/luci/menu.d/luci-app-mocktool.json  - 菜单配置
  usr/share/rpcd/acl.d/mocktool.json    - RPC 权限配置
  www/luci-static/resources/mocktool.css        - 样式表
  www/luci-static/resources/mocktool-logo-*.png - Logo 图标
  www/luci-static/resources/view/mocktool.js    - 前端页面
  install.sh                            - 安装脚本 (本文件)
