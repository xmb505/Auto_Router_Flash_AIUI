module("luci.controller.mocktool", package.seeall)

local http = require("luci.http")
local sys  = require("luci.sys")

local function parse_kv(text)
	local data = {}
	if not text then return data end
	for line in text:gmatch("[^\r\n]+") do
		local key, val = line:match("^([^=]+)=(.+)$")
		if key then
			data[key] = val
		end
	end
	return data
end

local function exec_mocktool(...)
	local args = { ... }
	local cmd = "/usr/libexec/mocktool-luci"
	for _, v in ipairs(args) do
		cmd = cmd .. " " .. v
	end
	local fd = io.popen(cmd .. " 2>&1", "r")
	if not fd then
		return { error = "failed to execute mocktool-luci" }
	end
	local output = fd:read("*a")
	fd:close()
	return parse_kv(output)
end

local function json_exit(data)
	http.prepare_content("application/json")
	http.write_json(data)
end

function index()
	entry({"admin", "network", "mocktool"}, template("mocktool"), _("小白无序修改工具"), 1)

	entry({"admin", "network", "mocktool", "status"},  call("action_status")).leaf = true
	entry({"admin", "network", "mocktool", "random"},  call("action_random")).leaf = true
	entry({"admin", "network", "mocktool", "manual"},  call("action_manual")).leaf = true
	entry({"admin", "network", "mocktool", "schedule"}, call("action_schedule")).leaf = true
end

function action_status()
	json_exit(exec_mocktool("status"))
end

function action_random()
	local ok, err = pcall(function()
		local fd = io.popen("/usr/bin/mocktool -x -restart 2>&1", "r")
		if fd then fd:read("*a"); fd:close() end
	end)
	if ok then
		json_exit({ ok = 1 })
	else
		json_exit({ error = tostring(err) })
	end
end

function action_manual()
	local wan_mac = http.formvalue("wan_mac") or ""
	local lan_mac = http.formvalue("lan_mac") or ""
	local lan_ip  = http.formvalue("lan_ip") or ""

	if lan_ip ~= "" and not lan_ip:match("^%d+%.%d+%.%d+%.%d+$") then
		json_exit({ error = "Invalid LAN IP address" })
		return
	end

	json_exit(exec_mocktool("manual", wan_mac, lan_mac, lan_ip))
end

function action_schedule()
	local enabled = http.formvalue("enabled") or "0"
	local hour = http.formvalue("hour") or "0"

	if enabled ~= "0" and enabled ~= "1" then
		json_exit({ error = "enabled must be 0 or 1" })
		return
	end
	if not hour:match("^%d+$") or tonumber(hour) < 0 or tonumber(hour) > 24 then
		json_exit({ error = "hour must be 0-24" })
		return
	end

	json_exit(exec_mocktool("schedule", enabled, hour))
end
